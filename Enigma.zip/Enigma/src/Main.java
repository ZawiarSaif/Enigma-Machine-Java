import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Rotor {
    private String wiring;
    private int position;
    private int turnover;  // Position at which the next rotor is advanced

    public Rotor(String wiring, int position, int turnover) {
        this.wiring = wiring;
        this.position = position;
        this.turnover = turnover;
    }

    public char forward(char letter) {
        int index = (letter - 'A' + position) % 26;
        return wiring.charAt(index);
    }

    public char backward(char letter) {
        int index = (wiring.indexOf(letter) - position + 26) % 26;
        return (char) ('A' + index);
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public boolean rotate() {
        position = (position + 1) % 26;
        return position == turnover;
    }
}

class Reflector {
    private String wiring;

    public Reflector(String wiring) {
        this.wiring = wiring;
    }

    public char reflect(char letter) {
        return wiring.charAt(letter - 'A');
    }
}

class EnigmaMachine {
    private Rotor[] rotors;
    private Reflector reflector;
    private Map<Character, Character> plugboard;

    public EnigmaMachine(Reflector reflector, Rotor rotor1, Rotor rotor2, Rotor rotor3, String plugs) {
        this.rotors = new Rotor[]{rotor1, rotor2, rotor3};
        this.reflector = reflector;
        this.plugboard = new HashMap<>();
        parsePlugboard(plugs);
    }

    private void parsePlugboard(String plugs) {
        String[] pairs = plugs.split(" ");
        for (String pair : pairs) {
            char first = pair.charAt(0);
            char second = pair.charAt(1);
            plugboard.put(first, second);
            plugboard.put(second, first);
        }
    }

    public char encrypt(char letter) {
        if (Character.isAlphabetic(letter)) {
            letter = Character.toUpperCase(letter);
            letter = plugboard.getOrDefault(letter, letter);

            // Forward through rotors
            for (Rotor rotor : rotors) {
                letter = rotor.forward(letter);
            }

            // Reflect
            letter = reflector.reflect(letter);

            // Backward through rotors
            for (int i = rotors.length - 1; i >= 0; i--) {
                letter = rotors[i].backward(letter);
            }

            // Through plugboard again
            letter = plugboard.getOrDefault(letter, letter);

            // Rotate the rotors
            boolean rotateNext = true;
            for (Rotor rotor : rotors) {
                if (rotateNext) {
                    rotateNext = rotor.rotate();
                } else {
                    break;
                }
            }
            return letter;
        }
        return letter; // If the character is not a letter, return it unchanged
    }

    public void setPosition(int rotorIndex, int position) {
        rotors[rotorIndex].setPosition(position);
    }
}

public class Main {
    public static void main(String[] args) {
        // Example rotor wirings (substitute with actual Enigma rotor wirings)
        String[] rotorWiring = {
                "EKMFLGDQVZNTOWYHXUSPAIBRCJ",  // Rotor I
                "AJDKSIRUXBLHWTMCQGZNPYFVOE",  // Rotor II
                "BDFHJLCPRTXVZNYEIWGAKMUSQO"   // Rotor III
        };

        // Turnover positions for the rotors, typically at the notch of the rotor
        int[] turnovers = {
                17,  // Rotor I steps at Q->R
                5,   // Rotor II steps at E->F
                22   // Rotor III steps at V->W
        };

        // Example reflector wiring (substitute with actual Enigma reflector wiring)
        String reflectorWiring = "EJMZALYXVBWFCRQUONTSPIKHGD";

        Reflector reflector = new Reflector(reflectorWiring);
        Rotor rotor1 = new Rotor(rotorWiring[0], 0, turnovers[0]);
        Rotor rotor2 = new Rotor(rotorWiring[1], 0, turnovers[1]);
        Rotor rotor3 = new Rotor(rotorWiring[2], 0, turnovers[2]);

        EnigmaMachine enigma = new EnigmaMachine(reflector, rotor1, rotor2, rotor3, "AV BS CG DL FU HZ IN KM OW RX");

        Scanner scanner = new Scanner(System.in);

        // Prompt for rotor initial positions
        System.out.print("Enter initial positions for Rotor I, II, III (e.g., 5 12 26): ");
        String[] positions = scanner.nextLine().split(" ");
        enigma.setPosition(0, Integer.parseInt(positions[0]));
        enigma.setPosition(1, Integer.parseInt(positions[1]));
        enigma.setPosition(2, Integer.parseInt(positions[2]));

        // Prompt for message to encrypt
        System.out.print("Enter the message to encrypt: ");
        String message = scanner.nextLine();

        StringBuilder encryptedMessage = new StringBuilder();
        for (char letter : message.toCharArray()) {
            encryptedMessage.append(enigma.encrypt(letter));
        }

        // Output the encrypted message
        System.out.println("Encrypted message: " + encryptedMessage.toString());

        // Reset rotor positions for decryption
        enigma.setPosition(0, Integer.parseInt(positions[0]));
        enigma.setPosition(1, Integer.parseInt(positions[1]));
        enigma.setPosition(2, Integer.parseInt(positions[2]));

        // Prompt for encrypted message to decrypt
        System.out.print("Enter the encrypted message to decrypt: ");
        String encryptedInput = scanner.nextLine();

        StringBuilder decryptedMessage = new StringBuilder();
        for (char letter : encryptedInput.toCharArray()) {
            decryptedMessage.append(enigma.encrypt(letter));
        }

        // Output the decrypted message
        System.out.println("Decrypted message: " + decryptedMessage.toString());

        scanner.close();
    }
}
